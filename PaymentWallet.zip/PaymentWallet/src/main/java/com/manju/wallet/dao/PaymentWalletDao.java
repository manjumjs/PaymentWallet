package com.manju.wallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;

import com.manju.wallet.bean.Customer;
import com.manju.wallet.dao.PaymentWalletDaoInterface;

public class PaymentWalletDao implements PaymentWalletDaoInterface {

	public boolean validateUserName(String userName) {

		boolean result = false;
		try {
			Connection con = JdbcConnection.getConnection();
			String query = "select * from customerDetails where customerName=?";
			PreparedStatement st2 = con.prepareStatement(query);
			st2.setString(1, userName);

			ResultSet rs = st2.executeQuery();
			while (rs.next()) {
				result = true;
			}

		} catch (Exception e) {
			System.out.println("" + e);

		}
		if (result)
			return true;
		else
			return false;

	}

	public boolean validateUserPin(String name, int userPin) {

		boolean result = false;
		try {
			Connection con = JdbcConnection.getConnection();
			String query = "select * from customerDetails where customerName=? and pin=? ";
			PreparedStatement st2 = con.prepareStatement(query);
			st2.setString(1, name);
			st2.setInt(2, userPin);
			ResultSet rs = st2.executeQuery();
			while (rs.next()) {
				result = true;
			}

		} catch (Exception e) {
			System.out.println("" + e);
			return false;
		}
		if (result)
			return true;
		else
			return false;

	}

	public int deposit(int amount, String userName) {
		int balance = 0;
		try {
			Connection con = JdbcConnection.getConnection();
			String query = "select balance from customerDetails where customerName=?";
			String updateQuery = "update customerDetails set balance=? where customerName=?";
			PreparedStatement st2 = con.prepareStatement(query);
			PreparedStatement stupdate = con.prepareStatement(updateQuery);
			st2.setString(1, userName);
			ResultSet rs = st2.executeQuery();
			while (rs.next()) {
				balance = rs.getInt("balance");

				balance += amount;

				stupdate.setInt(1, balance);
				stupdate.setString(2, userName);

				stupdate.executeUpdate();

			}

		} catch (Exception e) {
			System.out.println("" + e);

		}

		return balance;
	}

	public int withdraw(int amount, String userName) {
		int balance = 0;
		try {
			Connection con = JdbcConnection.getConnection();
			String query = "select balance from customerDetails where customerName=?";
			String updateQuery = "update customerDetails set balance=? where customerName=?";
			PreparedStatement st2 = con.prepareStatement(query);
			PreparedStatement stupdate = con.prepareStatement(updateQuery);
			st2.setString(1, userName);
			ResultSet rs = st2.executeQuery();
			while (rs.next()) {
				balance = rs.getInt("balance");
				if (balance > amount) {
					balance -= amount;

					stupdate.setInt(1, balance);
					stupdate.setString(2, userName);

					stupdate.executeUpdate();
				} else {
					System.out.println("Not Enough Fund");
				}
			}

		} catch (Exception e) {
			System.out.println("" + e);

		}

		return balance;

	}

}
