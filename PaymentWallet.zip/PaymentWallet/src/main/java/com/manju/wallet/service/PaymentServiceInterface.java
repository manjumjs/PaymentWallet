package com.manju.wallet.service;

public interface PaymentServiceInterface {

	boolean validateUserName(String userName);

	boolean validateUserPin(String name, int userPin);

	int withdraw(int amount, String userName);

	int deposit(int amount, String userName);

}
