package com.manju.wallet.service;

import java.util.Map;

import com.manju.wallet.bean.Customer;
import com.manju.wallet.dao.PaymentWalletDao;
import com.manju.wallet.service.PaymentServiceInterface;

public class PaymentWalletService implements PaymentServiceInterface {

	PaymentWalletDao dao = new PaymentWalletDao();

	@Override
	public boolean validateUserName(String userName) {

		return dao.validateUserName(userName);
	}

	public boolean validateUserPin(String name, int userPin) {
		return dao.validateUserPin(name, userPin);
	}

	public int withdraw(int amount, String userName) {
		return dao.withdraw(amount, userName);
	}

	public int deposit(int amount, String userName) {

		return dao.deposit(amount, userName);
	}

}
