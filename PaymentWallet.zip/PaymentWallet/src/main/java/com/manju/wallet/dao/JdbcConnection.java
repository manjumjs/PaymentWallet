package com.manju.wallet.dao;

import java.sql.*;

public class JdbcConnection {

	public static Connection getConnection() {
		Connection con = null;
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/PaymentWallet?serverTimezone=UTC", "root",
					"");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
}
