package com.manju.wallet.ui;

import java.util.Scanner;

import com.manju.wallet.service.PaymentWalletService;

public class PaymentWalletUi {
	public static void main(String[] args) {

		String name;
		int pin;
		int choice;

		PaymentWalletService service = new PaymentWalletService();

		while (true) {
			Scanner scan = new Scanner(System.in);
			System.out.println("Enter the user name :");
			name = scan.next();

			boolean isValidname = service.validateUserName(name);

			if (isValidname)// else
			{

				System.out.println("Enter the 4-digit pin :");
				pin = scan.nextInt();

				boolean isValidpin = service.validateUserPin(name, pin);

				if (isValidpin) {
					System.out.println("Please Select the transaction \n 1.DEPOSIT\t2.WITHDRAW");

					choice = scan.nextInt();

					int amount;
					int balance;

					switch (choice) {
					case 1:
						System.out.println("\nEnter Amount for Deposit :");
						amount = scan.nextInt();
						balance = service.deposit(amount, name);
						System.out.println("Balance =" + balance);
						break;

					case 2:
						System.out.println("\nEnter Amount for Withdraw :");
						amount = scan.nextInt();
						balance = service.withdraw(amount, name);
						System.out.println("Balance =" + balance);
						break;

					default:
						System.out.println("\nPlease Enter the Valid Option");

					}

					System.out.println("\nYou want to make another transaction?(y/n):");
					char c = scan.next().charAt(0);
					if (c == 'n') {
						break;
					}

				} else {
					System.out.println("Please Enter Valid pin");
				}

			} else {
				System.out.println("Please Enter Valid User Name");
			}

		}
		System.out.println("Thank You For Using Our System!! ");
	}
}
