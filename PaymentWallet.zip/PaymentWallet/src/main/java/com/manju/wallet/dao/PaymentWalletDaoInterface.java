package com.manju.wallet.dao;

public interface PaymentWalletDaoInterface {

	int withdraw(int amount, String userName);

	int deposit(int amount, String userName);

	boolean validateUserName(String userName);

	boolean validateUserPin(String name, int userPin);

}
